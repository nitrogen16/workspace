package com.ipipeline.automation.config;

import java.io.File;
import java.nio.file.Paths;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.kohsuke.args4j.Option;

import com.ipipeline.automation.driver.BrowserType;
import com.ipipeline.ngsd.kedr.tests.config.IgoConfig;

public class TestConfig {
	
	private static final String DEFAULT_DRIVER_DIR = "drivers";
	private static final String BROWSER_PROP = "browser";
	private static final String URL_PROP = "url";
	
	private static final String DEFAULT_JIRA_USERNAME = "qaautomation";
	private static final String DEFAULT_JIRA_PASSWORD = "q@utoma!e";
	
	private static final File DOWNLOAD_DIR = Paths.get("version").toFile();

	@Option(name = "-source")
	private String source;
	
	@Option(name = "-" + BROWSER_PROP)
	private String browser;
	
	@Option(name = "-driverDir")
	private String driverDir = DEFAULT_DRIVER_DIR;

	@Option(name = "-" + URL_PROP)
	private String igoUrl;
	@Option(name = "-user")
	private String igoUser;
	@Option(name = "-password")
	private String igoPassword;
	@Option(name = "-state")
	private String igoState;
	@Option(name = "-product.type")
	private String igoProductType;
	@Option(name = "-product")
	private String igoProduct;
	
	@Option(name = "-rp")
	private boolean useRP = true;
	
	@Option(name = "-saucelabs")
	private boolean sauceLabs;
	@Option(name = "-saucelabs.username")
	private String userName;
	@Option(name = "-saucelabs.accesskey")
	private String accessKey;
	@Option(name = "-saucelabs.browser.version")
	private String browserVersion;
	@Option(name = "-saucelabs.platform")
	private String platform;
	@Option(name = "-saucelabs.name")
	private String testName;
	
	@Option(name = "-download.dir")
	private File downloadDir = DOWNLOAD_DIR;

	@Option(name = "-pdf.base.dir")
	private String pdfBaseDir;

	@Option(name = "-bc.dir")
	private String bcDir;

	@Option(name = "-keepBrowser")
	private boolean keepBrowser;

	@Option(name = "-highlight")
	private boolean highlight;

	@Option(name = "-jira")
	private boolean jira;
	
	@Option(name = "-jira.username")
	private String jiraUsername = DEFAULT_JIRA_USERNAME;
	
	@Option(name = "-jira.password")
	private String jiraPassword = DEFAULT_JIRA_PASSWORD;
	
	private Map<String, Properties> suiteProperties;
	private String suitesName;
	private IgoConfig igoConfig;

	public String getSource() {
		return source;
	}
	
	public BrowserType getBrowserType() {
		String caseBrowser = getSuiteProperties().getProperty(BROWSER_PROP);
		try {
			if (StringUtils.isNotBlank(caseBrowser)) {
				return BrowserType.valueOf(caseBrowser);
			} else {
				return BrowserType.valueOf(browser.toUpperCase());
			}
		} catch (Exception e) {
			return BrowserType.valueOf(browser.toUpperCase());
		}
	}
	
	public String getDriverDir() {
		return driverDir;
	}

	public String getIgoUrl() {
		return getSuiteProperties().getProperty(URL_PROP, igoUrl);
	}

	public String getIgoUser() {
		return igoUser;
	}

	public String getIgoPassword() {
		return igoPassword;
	}

	public String getIgoState() {
		return igoState;
	}

	public String getIgoProductType() {
		return igoProductType;
	}

	public String getIgoProduct() {
		return igoProduct;
	}
	
	public boolean isUseRP() {
		return useRP;
	}
	
	public boolean isSauceLabs() {
		return sauceLabs;
	}
	
	public String getUserName() {
		return userName;
	}
	
	public String getAccessKey() {
		return accessKey;
	}
	
	public String getPlatform() {
		return platform;
	}
	
	public String getBrowserVersion() {
		return browserVersion;
	}
	
	public String getTestName() {
		return testName;
	}

	public Properties getSuiteProperties() {
		if(igoConfig != null) {
			suitesName = igoConfig.getSuiteName();
		}
		return null == suitesName ? new Properties() : suiteProperties.get(suitesName);
	}

	public void setSuitesProperties(Map<String, Properties> suitesProperties) {
		this.suiteProperties = suitesProperties;
	}

	public String getSuiteName() {
		return suitesName;
	}

	public void setSuitesName(String suiteName) {
		this.suitesName = suiteName;
	}

	public IgoConfig getIgoConfig() {
		return igoConfig;
	}

	public void setIgoConfig(IgoConfig igoConfig) {
		this.igoConfig = igoConfig;
	}
	
	public File getDownloadDir() {
		return downloadDir;
	}
	
	public boolean isJira() {
		return jira;
	}

	public String getJiraUsername() {
		return jiraUsername;
	}

	public String getJiraPassword() {
		return jiraPassword;
	}

	public boolean isKeepBrowser() {
		return keepBrowser;
	}

	public void setKeepBrowser(boolean keepBrowser) {
		this.keepBrowser = keepBrowser;
	}

	public String getPdfBaseDir() {
		return pdfBaseDir;
	}

	public void setPdfBaseDir(String pdfBaseDir) {
		this.pdfBaseDir = pdfBaseDir;
	}

	public String getBcDir() {
		return bcDir;
	}

	public void setBcDir(String bcDir) {
		this.bcDir = bcDir;
	}

	public boolean isHighlight() {
		return highlight;
	}

	public void setHighlight(boolean highlight) {
		this.highlight = highlight;
	}

}