package com.ipipeline.automation.driver;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.TargetLocator;
import org.openqa.selenium.WebElement;

public class TargetLocatorDecorator implements TargetLocator {

	private TargetLocator targetLocator;
	private List<ExceptionHandler> exceptionHandlers = new LinkedList<ExceptionHandler>();

	public TargetLocatorDecorator(TargetLocator targetLocator, List<ExceptionHandler> exceptionHandlers) {
		super();
		this.targetLocator = targetLocator;
		this.exceptionHandlers = exceptionHandlers;
	}

	@Override
	public WebDriver frame(int index) {
		try {
			return targetLocator.frame(index);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return frame(index);
		}
	}

	@Override
	public WebDriver frame(String nameOrId) {
		try {
			return targetLocator.frame(nameOrId);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return frame(nameOrId);
		}
	}

	@Override
	public WebDriver frame(WebElement frameElement) {
		try {
			return targetLocator.frame(frameElement);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return frame(frameElement);
		}
	}

	@Override
	public WebDriver parentFrame() {
		try {
			return targetLocator.parentFrame();
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return parentFrame();
		}
	}

	@Override
	public WebDriver window(String nameOrHandle) {
		try {
			return targetLocator.window(nameOrHandle);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return window(nameOrHandle);
		}
	}

	@Override
	public WebDriver defaultContent() {
		try {
			return targetLocator.defaultContent();
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return defaultContent();
		}
	}

	@Override
	public WebElement activeElement() {
		try {
			return targetLocator.activeElement();
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return activeElement();
		}
	}

	@Override
	public Alert alert() {
		try {
			return targetLocator.alert();
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);
			
			return alert();
		}
	}

}