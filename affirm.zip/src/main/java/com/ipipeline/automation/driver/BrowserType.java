package com.ipipeline.automation.driver;

public enum BrowserType {
	
	EDGE,
	FF,
	GC,
	IE;

}