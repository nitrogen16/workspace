package com.ipipeline.automation.driver;

/**
 * @author Aliaksei_Breilian
 * 
 * Interface to handle particular exceptions during calling of WebDrivers methods.
 */
public interface ExceptionHandler {

	/**
	 * Verify is this Handler responsible for handling thrown exception.
	 * 
	 * @param e is thrown exception
	 * @return true if exception is suitable for this handler
	 */
	boolean isAppropriateForException(Exception e);

	/**
	 * Process or throw further given thrown exception.
	 * 
	 * @param e is thrown exception
	 */
	void handleException(Exception e);

}
