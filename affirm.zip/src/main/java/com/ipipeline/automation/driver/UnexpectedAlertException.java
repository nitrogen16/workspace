package com.ipipeline.automation.driver;

import com.ipipeline.ngsd.ui.igo.elements.exceptions.UIRuntimeException;

@SuppressWarnings("serial")
public class UnexpectedAlertException extends UIRuntimeException {

	public UnexpectedAlertException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UnexpectedAlertException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public UnexpectedAlertException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public UnexpectedAlertException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
