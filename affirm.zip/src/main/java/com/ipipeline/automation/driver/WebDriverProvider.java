package com.ipipeline.automation.driver;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;

import org.apache.commons.lang3.SystemUtils;
import org.openqa.selenium.NoSuchSessionException;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.google.inject.Inject;
import com.google.inject.Provider;
import com.ipipeline.automation.Runner;
import com.ipipeline.automation.config.TestConfig;
import com.ipipeline.ngsd.kedr.tests.base.WDProvider;
import com.ipipeline.ngsd.kedr.tests.exceptions.TestRuntimeException;

public class WebDriverProvider implements Provider<WebDriver>, WDProvider {

	private static final String CHROME_DRIVER_WIN = "chromedriver.exe";
	private static final String CHROME_DRIVER_LIN = "chromedriver";
	private static final String CHROME_PROPERTY = "webdriver.chrome.driver";
	private static final String EDGE_DRIVER = "MicrosoftWebDriver.exe";
	private static final String EDGE_PROPERTY = "webdriver.edge.driver";
	private static final String FF_DRIVER = "geckodriver.exe";
	private static final String FF_PROPERTY = "webdriver.gecko.driver";
	private static final String IE_DRIVER = "IEDriverServer.exe";
	private static final String IE_PROPERTY = "webdriver.ie.driver";

	private final TestConfig config;

	private LinkedList<WebDriver> driversPool = new LinkedList<WebDriver>();

	@Inject
	public WebDriverProvider(TestConfig config) {
		this.config = config;
	}

	@Override
	public WebDriver get() {
		if (!driversPool.isEmpty()) {
			try {
				// verify if browser closed
				driversPool.getLast().getWindowHandle();

				return driversPool.getLast();
			} catch (NoSuchSessionException e) {
				driversPool.removeLast();

				return get();
			}
		}

		// pool is empty
		// open new browser and return
		openNew();

		return get();
	}

	@Override
	public void openNew() {
		WebDriver driver = null;

		if (config.isSauceLabs()) {
			try {
				driver = createSauceLabsWebDriver();
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			switch (config.getBrowserType()) {
			case GC:
				driver = createChromeDriver();
				break;
			case EDGE:
				driver = createEdgeWebDriver();
				break;
			case FF:
				driver = createFirefoxWebDriver();
				break;
			case IE:
				driver = createInternetExplorerWebDriver();
				break;
			default:
				throw new TestRuntimeException("Unsupported browser type " + config.getBrowserType());
			}
		}
		driversPool.add(driver);
	}

	private DesiredCapabilities getCapabilities() {
		DesiredCapabilities capabilities = new DesiredCapabilities();

		// if (config.isTestMeasurement()) {
		// capabilities.setCapability(CapabilityType.PROXY, new
		// ProxyService().getProxyInstance());
		// }

		capabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);

		return capabilities;
	}

	private WebDriver createChromeDriver() {
		File chromeDriver;

		if (SystemUtils.IS_OS_LINUX) {
			chromeDriver = new File(config.getDriverDir(), CHROME_DRIVER_LIN);
			chromeDriver.setExecutable(true);
		} else {
			chromeDriver = new File(config.getDriverDir(), CHROME_DRIVER_WIN);
		}

		System.setProperty(CHROME_PROPERTY, chromeDriver.getAbsolutePath());

		HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
		chromePrefs.put("download.default_directory", Runner.getConfig().getDownloadDir().getAbsolutePath());

		HashMap<String, Object> plugin = new HashMap<String, Object>();
		plugin.put("enabled", false);
		plugin.put("name", "Chrome PDF Viewer");
		chromePrefs.put("plugins.plugins_list", Arrays.asList(plugin));

		DesiredCapabilities capabilities = getCapabilities();
		ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.addArguments("test-type");
		chromeOptions.setExperimentalOption("prefs", chromePrefs);
		chromeOptions.addArguments("no-sandbox");

		capabilities.setCapability(ChromeOptions.CAPABILITY, chromeOptions);

		return new WebDriverDecorator(new ChromeDriver(capabilities));
	}

	private WebDriver createEdgeWebDriver() {
		System.setProperty(EDGE_PROPERTY, new File(config.getDriverDir(), EDGE_DRIVER).getAbsolutePath());

		return new WebDriverDecorator(new EdgeDriver(getCapabilities()));
	}

	private WebDriver createFirefoxWebDriver() {
		System.setProperty(FF_PROPERTY, new File(config.getDriverDir(), FF_DRIVER).getAbsolutePath());
		DesiredCapabilities capabilities = getCapabilities();
		capabilities.setCapability(FirefoxDriver.PROFILE, getFirefoxProfile());

		return new WebDriverDecorator(new FirefoxDriver(capabilities));
	}

	private WebDriver createInternetExplorerWebDriver() {
		System.setProperty(IE_PROPERTY, new File(config.getDriverDir(), IE_DRIVER).getAbsolutePath());
		return new WebDriverDecorator(new InternetExplorerDriver(getCapabilities()));
	}

	private FirefoxProfile getFirefoxProfile() {
		FirefoxProfile profile = new FirefoxProfile();
		profile.setPreference("toolkit.startup.max_resumed_crashes", "-1");

		return profile;
	}

	@Override
	public void quit() {
		if (!driversPool.isEmpty()) {
			driversPool.getLast().quit();
			driversPool.removeLast();
		}
	}

	@Override
	public void quitAll() {
		// TODO Auto-generated method stub
	}

	private WebDriver createSauceLabsWebDriver() throws MalformedURLException {
		DesiredCapabilities caps = null;
		switch (config.getBrowserType()) {
		case EDGE:
			caps = DesiredCapabilities.edge();
			break;
		case FF:
			caps = DesiredCapabilities.firefox();
			break;
		case GC:
			caps = DesiredCapabilities.chrome();
			break;
		case IE:
			caps = DesiredCapabilities.internetExplorer();
			break;
		default:
			throw new TestRuntimeException("Unsupported browser type " + config.getBrowserType());
		}
		caps.setCapability("version", config.getBrowserVersion());
		caps.setCapability("platform", config.getPlatform());
		caps.setCapability("name", config.getTestName());
		return new RemoteWebDriver(getSauceLabsURL(), caps);
	}

	private URL getSauceLabsURL() throws MalformedURLException {
		return new URL(String.format("https://%s:%s@ondemand.saucelabs.com:443/wd/hub", config.getUserName(), config.getAccessKey()));
	}

}