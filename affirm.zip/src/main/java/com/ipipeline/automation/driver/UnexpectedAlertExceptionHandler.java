package com.ipipeline.automation.driver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class UnexpectedAlertExceptionHandler implements ExceptionHandler {

	private WebDriver driver;

	public UnexpectedAlertExceptionHandler(WebDriver driver) {
		this.driver = driver;
	}

	@Override
	public boolean isAppropriateForException(Exception e) {
		try {
			return false;
//			return !driver.findElements(By.xpath("//div[@class='modal-primary modal-dialog']")).isEmpty();
		} catch (Exception e2) {
			return false;
		}
	}

	@Override
	public void handleException(Exception e) {
		String alertMessage = driver.findElement(By.className("modal-body")).getText();
		
		throw new UnexpectedAlertException("Unexpected Alert. Message : \"" + alertMessage + "\"");
	}

}
