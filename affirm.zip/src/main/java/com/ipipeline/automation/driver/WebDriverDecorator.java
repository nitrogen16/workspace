package com.ipipeline.automation.driver;

import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import com.ipipeline.automation.Runner;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Keyboard;
import org.openqa.selenium.interactions.Mouse;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class WebDriverDecorator extends RemoteWebDriver {

	private RemoteWebDriver remoteDriver;
	private List<ExceptionHandler> exceptionHandlers = new LinkedList<ExceptionHandler>();

	public WebDriverDecorator(RemoteWebDriver remoteDriver) {
		this.remoteDriver = remoteDriver;
		setDefaultAlertsHandler();
	}

	public void setDefaultAlertsHandler() {
		WebDriverService.removeHandler(UnexpectedAlertExceptionHandler.class, exceptionHandlers);
		exceptionHandlers.add(new UnexpectedAlertExceptionHandler(this));
	}

	@Override
	public void close() {
		try {
			remoteDriver.close();
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			close();
		}
	}

	@Override
	public WebElement findElement(By arg0) {
		try {
			WebElement element = remoteDriver.findElement(arg0);
			if(Runner.getConfig().isHighlight()){
				highlightElementMilliseconds(this, element, 250);
			}
			return WebElementDecorator.wrapElement(element, arg0, exceptionHandlers);
//			return remoteDriver.findElement(arg0);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);
			
			return findElement(arg0);
		}
	}

	private void highlightElementMilliseconds(WebDriver driver, WebElement element, int milliseconds) {
		String bg = element.getCssValue("backgroundColor");
		JavascriptExecutor js = ((JavascriptExecutor) driver);
		js.executeScript("arguments[0].style.backgroundColor = '" + "yellow" + "'", element);
		sleep(milliseconds);
		js.executeScript("arguments[0].style.backgroundColor = '" + bg + "'", element);
	}

	private void sleep(int millis) {
		try {
			Thread.sleep(millis);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public List<WebElement> findElements(By arg0) {
		try {
			return WebElementDecorator.wrapElements(remoteDriver.findElements(arg0), arg0, exceptionHandlers);
//			return remoteDriver.findElements(arg0);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return findElements(arg0);
		}
	}

	@Override
	public void get(String arg0) {
		try {
			remoteDriver.get(arg0);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			get(arg0);
		}
	}

	@Override
	public String getCurrentUrl() {
		try {
			return remoteDriver.getCurrentUrl();
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return getCurrentUrl();
		}
	}

	@Override
	public String getPageSource() {
		try {
			return remoteDriver.getPageSource();
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return getPageSource();
		}
	}

	@Override
	public String getTitle() {
		try {
			return remoteDriver.getTitle();
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return getTitle();
		}
	}

	@Override
	public String getWindowHandle() {
		try {
			return remoteDriver.getWindowHandle();
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return getWindowHandle();
		}
	}

	@Override
	public Set<String> getWindowHandles() {
		try {
			return remoteDriver.getWindowHandles();
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return getWindowHandles();
		}
	}

	@Override
	public Options manage() {
		try {
			return remoteDriver.manage();
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return manage();
		}
	}

	@Override
	public Navigation navigate() {
		try {
			return remoteDriver.navigate();
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return navigate();
		}
	}

	@Override
	public void quit() {
		try {
			remoteDriver.quit();
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			quit();
		}
	}

	@Override
	public TargetLocator switchTo() {
		try {
			return new TargetLocatorDecorator(remoteDriver.switchTo(), exceptionHandlers);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return switchTo();
		}
	}

	@Override
	public <X> X getScreenshotAs(OutputType<X> arg0) throws WebDriverException {
		try {
			return remoteDriver.getScreenshotAs(arg0);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return getScreenshotAs(arg0);
		}
	}

	@Override
	public Capabilities getCapabilities() {
		try {
			return remoteDriver.getCapabilities();
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return getCapabilities();
		}
	}

	@Override
	public Keyboard getKeyboard() {
		try {
			return remoteDriver.getKeyboard();
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return getKeyboard();
		}
	}

	@Override
	public Mouse getMouse() {
		try {
			return remoteDriver.getMouse();
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return getMouse();
		}
	}

	@Override
	public WebElement findElementByXPath(String arg0) {
		try {
			return remoteDriver.findElementByXPath(arg0);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return findElementByXPath(arg0);
		}
	}

	@Override
	public List<WebElement> findElementsByXPath(String arg0) {
		try {
			return remoteDriver.findElementsByXPath(arg0);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return findElementsByXPath(arg0);
		}
	}

	@Override
	public WebElement findElementByTagName(String arg0) {
		try {
			return remoteDriver.findElementByTagName(arg0);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return findElementByTagName(arg0);
		}
	}

	@Override
	public List<WebElement> findElementsByTagName(String arg0) {
		try {
			return remoteDriver.findElementsByTagName(arg0);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return findElementsByTagName(arg0);
		}
	}

	@Override
	public WebElement findElementByCssSelector(String arg0) {
		try {
			return remoteDriver.findElementByCssSelector(arg0);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return findElementByCssSelector(arg0);
		}
	}

	@Override
	public List<WebElement> findElementsByCssSelector(String arg0) {
		try {
			return remoteDriver.findElementsByCssSelector(arg0);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return findElementsByCssSelector(arg0);
		}
	}

	@Override
	public WebElement findElementByName(String arg0) {
		try {
			return remoteDriver.findElementByName(arg0);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return findElementByName(arg0);
		}
	}

	@Override
	public List<WebElement> findElementsByName(String arg0) {
		try {
			return remoteDriver.findElementsByName(arg0);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return findElementsByName(arg0);
		}
	}

	@Override
	public WebElement findElementByLinkText(String arg0) {
		try {
			return remoteDriver.findElementByLinkText(arg0);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return findElementByLinkText(arg0);
		}
	}

	@Override
	public WebElement findElementByPartialLinkText(String arg0) {
		try {
			return remoteDriver.findElementByPartialLinkText(arg0);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return findElementByPartialLinkText(arg0);
		}
	}

	@Override
	public List<WebElement> findElementsByLinkText(String arg0) {
		try {
			return remoteDriver.findElementsByLinkText(arg0);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return findElementsByLinkText(arg0);
		}
	}

	@Override
	public List<WebElement> findElementsByPartialLinkText(String arg0) {
		try {
			return remoteDriver.findElementsByPartialLinkText(arg0);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return findElementsByPartialLinkText(arg0);
		}
	}

	@Override
	public WebElement findElementByClassName(String arg0) {
		try {
			return remoteDriver.findElementByClassName(arg0);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return findElementByClassName(arg0);
		}
	}

	@Override
	public List<WebElement> findElementsByClassName(String arg0) {
		try {
			return remoteDriver.findElementsByClassName(arg0);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return findElementsByClassName(arg0);
		}
	}

	@Override
	public WebElement findElementById(String arg0) {
		try {
			return remoteDriver.findElementById(arg0);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return findElementById(arg0);
		}
	}

	@Override
	public List<WebElement> findElementsById(String arg0) {
		try {
			return remoteDriver.findElementsById(arg0);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return findElementsById(arg0);
		}
	}

	@Override
	public Object executeAsyncScript(String arg0, Object... arg1) {
		try {
			return remoteDriver.executeAsyncScript(arg0, arg1);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return executeAsyncScript(arg0, arg1);
		}
	}

	@Override
	public Object executeScript(String arg0, Object... arg1) {
		try {
			return remoteDriver.executeScript(arg0, arg1);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return executeScript(arg0, arg1);
		}
	}

	public RemoteWebDriver getRemoteDriver() {
		return remoteDriver;
	}

}