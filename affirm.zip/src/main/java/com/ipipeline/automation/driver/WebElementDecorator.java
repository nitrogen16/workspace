package com.ipipeline.automation.driver;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.RemoteWebElement;

public class WebElementDecorator extends RemoteWebElement {

	private WebElement wrapedElement;
	private By locatedBy;
	private final int index;
	private final boolean isSingle;
	private List<ExceptionHandler> exceptionHandlers = new LinkedList<ExceptionHandler>();

	public WebElementDecorator(RemoteWebElement wrapedElement, By locatedBy, List<ExceptionHandler> exceptionHandlers) {
		this(wrapedElement, locatedBy, 0, true, exceptionHandlers);
	}

	public WebElementDecorator(RemoteWebElement wrapedElement, By locatedBy, int index, List<ExceptionHandler> exceptionHandlers) {
		this(wrapedElement, locatedBy, index, false, exceptionHandlers);
	}

	private WebElementDecorator(RemoteWebElement wrapedElement, By locatedBy, int index, boolean isSingle, List<ExceptionHandler> exceptionHandlers) {
		super();
		
		this.wrapedElement = wrapedElement;
		this.locatedBy = locatedBy;
		this.index = index;
		this.isSingle = isSingle;
		this.exceptionHandlers.addAll(exceptionHandlers);
		
		setId(wrapedElement.getId());
		setParent((RemoteWebDriver) wrapedElement.getWrappedDriver());
		this.exceptionHandlers.add(new StaleElementReferenceExceptionHandler());
	}

	@Override
	public WebDriver getWrappedDriver() {
		return ((RemoteWebElement) wrapedElement).getWrappedDriver();
	}

	@Override
	public void click() {
		try {
			wrapedElement.click();
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			click();
		}
	}

	@Override
	public void submit() {
		try {
			wrapedElement.submit();
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			submit();
		}
	}

	@Override
	public void sendKeys(CharSequence... keysToSend) {
		try {
			wrapedElement.sendKeys(keysToSend);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			sendKeys(keysToSend);
		}
	}

	@Override
	public void clear() {
		try {
			wrapedElement.clear();
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			clear();
		}
	}

	@Override
	public String getTagName() {
		try {
			return wrapedElement.getTagName();
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return getTagName();
		}
	}

	@Override
	public String getAttribute(String name) {
		try {
			return wrapedElement.getAttribute(name);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return getAttribute(name);
		}
	}

	@Override
	public boolean isSelected() {
		try {
			return wrapedElement.isSelected();
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return isSelected();
		}
	}

	@Override
	public boolean isEnabled() {
		try {
			return wrapedElement.isEnabled();
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return isEnabled();
		}
	}

	@Override
	public String getText() {
		try {
			return wrapedElement.getText();
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return getText();
		}
	}

	@Override
	public List<WebElement> findElements(By by) {
		try {
			return wrapElements(wrapedElement.findElements(by), by, exceptionHandlers);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return findElements(by);
		}
	}

	@Override
	public WebElement findElement(By by) {
		try {
			return wrapElement(wrapedElement.findElement(by), by, exceptionHandlers);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return findElement(by);
		}
	}

	@Override
	public boolean isDisplayed() {
		try {
			return wrapedElement.isDisplayed();
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return isDisplayed();
		}
	}

	@Override
	public Point getLocation() {
		try {
			return wrapedElement.getLocation();
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return getLocation();
		}
	}

	@Override
	public Dimension getSize() {
		try {
			return wrapedElement.getSize();
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return getSize();
		}
	}

	@Override
	public String getCssValue(String propertyName) {
		try {
			return wrapedElement.getCssValue(propertyName);
		} catch (Exception e) {
			WebDriverService.verifyHandlers(e, exceptionHandlers);

			return getCssValue(propertyName);
		}
	}

	public static WebElement wrapElement(WebElement element, By locatedBy, List<ExceptionHandler> exceptionHandlers) {
		return new WebElementDecorator((RemoteWebElement) element, locatedBy, exceptionHandlers);
	}

	public static List<WebElement> wrapElements(List<WebElement> elements, By locatedBy, List<ExceptionHandler> exceptionHandlers) {
		List<WebElement> wrappedElements = new LinkedList<WebElement>();
		
		for (int i = 0; i < elements.size(); i++) {
			WebElement element = elements.get(i);
			wrappedElements.add(new WebElementDecorator((RemoteWebElement) element, locatedBy, i, exceptionHandlers));
		}
		
		return wrappedElements;
	}

	class StaleElementReferenceExceptionHandler implements ExceptionHandler {

		@Override
		public boolean isAppropriateForException(Exception e) {
			return e instanceof StaleElementReferenceException;
		}

		@Override
		public void handleException(Exception e) {
			// TODO
			// After StaleElementReferenceException driver switches focus on default content of current window.
			// Correct solution to handle exception is save window handles and frame ids as well (except By locator and index).
			// It noted that StaleElementReferenceException occurs on Application screen. So As fast workaround just execute row below.
//			try {
//				PageFactory.getAppPage(getWrappedDriver()).getWindow().switchOn();
//			} catch (Throwable th) {
//				
//			}
//			
			if (isSingle) {
				wrapedElement = getWrappedDriver().findElement(locatedBy);
				System.out.println("RELOCATED " + locatedBy);
			} else {
				wrapedElement = getWrappedDriver().findElements(locatedBy).get(index);
				System.out.println("RELOCATED " + index + " -- " + locatedBy);
			}
			
//			setId(((RemoteWebElement) wrapedElement).getId());
		}

	}

}
