package com.ipipeline.automation.driver;

import java.util.Iterator;
import java.util.List;

public class WebDriverService {

	static void verifyHandlers(Exception e, List<ExceptionHandler> exceptionHandlers) {
		int passedHandlers = 0;
		
		for (ExceptionHandler handler : exceptionHandlers) {
			if (handler.isAppropriateForException(e)) {
				handler.handleException(e);
				passedHandlers++;
			}
		}
		
		if (passedHandlers == 0) {
			throw (RuntimeException) e;
		}
	}

	static void removeHandler(Class<? extends ExceptionHandler> classOfHandler, List<ExceptionHandler> exceptionHandlers) {
		Iterator<ExceptionHandler> iterator = exceptionHandlers.iterator();
		
		while (iterator.hasNext()) {
			ExceptionHandler handler = iterator.next();
			
			if (handler.getClass().equals(classOfHandler)) {
				iterator.remove();
			}
		}
	}

}
