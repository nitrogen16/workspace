package com.ipipeline.automation.affirm.affirmPageScope;

import com.ipipeline.ngsd.ui.igo.pages.Page;
import com.ipipeline.ngsd.ui.utils.DriverUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

/**
 * Created by Aliaksandr_Vasilets on 7/21/2017.
 */
public class AfDialogPage extends Page {

    private static final String CONFIRMATION_DIALOG_XPATH = "//div[@role='dialog']";
    private static final String CONFIRM_XPATH = "//span[@class='ui-button-text' and text()='OK']";
    private static final String CANCEL_XPATH = "//span[@class='ui-button-text' and text()='Cancel']";
    private static final String CLOSE_XPATH = "//span[@class='ui-icon ui-icon-closethick' and text()='close']";
    private static final String MSG_XPATH = "//span[@class='ErrorText']";

    @FindBy(id = "Body")
    private WebElement body;

    public AfDialogPage(WebDriver driver) {
        super(driver);
        waitForLoaded();
    }

    public void waitForLoaded() {
        DriverUtils.waitFor(getDriver(), () -> {
            return !body.getAttribute("style").equals("cursor: wait;");
        });
    }

    public List<WebElement> getConfirmationWindow(){
        return getDriver().findElements(By.xpath(CONFIRMATION_DIALOG_XPATH));
    }

    public void confirmDialog() {
        getConfirmationWindow().get(0).findElement(By.xpath(CONFIRM_XPATH)).click();
    }

    public void cancelDialog() {
        getConfirmationWindow().get(0).findElement(By.xpath(CANCEL_XPATH)).click();
    }

    public void closeDialog() {
        getConfirmationWindow().get(0).findElement(By.xpath(CLOSE_XPATH)).click();
    }

    public boolean isOrderSubmitted() {
        return getConfirmationWindow().get(0).findElement(By.xpath(MSG_XPATH)).getText().contains("Thank you for your order, it has now been submitted.");
    }
}
