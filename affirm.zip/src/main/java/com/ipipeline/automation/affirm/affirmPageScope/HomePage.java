package com.ipipeline.automation.affirm.affirmPageScope;

import com.ipipeline.ngsd.ui.igo.pages.IgoPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Created by Aliaksandr_Vasilets on 7/14/2017.
 */
public class HomePage extends IgoPage {


    @FindBy(linkText = "Order Entry Dashboard")

    private WebElement orderEntryDashboardLink;


    public HomePage(WebDriver driver) {
        super(driver);

    }

    public AnnuityOrdersPage orderEntryDashboard() {
        orderEntryDashboardLink.click();

        return switchToPage(AnnuityOrdersPage.class);
    }

}