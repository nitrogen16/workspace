package com.ipipeline.automation.affirm.control;

import com.ipipeline.ngsd.ui.elements.base.NGSDSelect;
import com.ipipeline.ngsd.ui.igo.elements.IgoDropdownControl;
import org.openqa.selenium.WebElement;

/**
 * Created by Aliaksandr_Vasilets on 7/14/2017.
 */
public class AfDropdownControl extends IgoDropdownControl {

    public AfDropdownControl(WebElement wrappedElement) {
        super(wrappedElement);
    }

    @Override
    public NGSDSelect getElement() {
        return new NGSDSelect(getWrappedElement());
    }

}
