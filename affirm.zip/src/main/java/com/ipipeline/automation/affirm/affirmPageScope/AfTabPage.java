package com.ipipeline.automation.affirm.affirmPageScope;

import com.ipipeline.ngsd.ui.igo.pages.Page;
import com.ipipeline.ngsd.ui.utils.DriverUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Created by Aliaksandr_Vasilets on 7/19/2017.
 */
public class AfTabPage extends Page {

    @FindBy(xpath = "//a/strong[text()='Show message(s)']")
    private WebElement errorMsg;
    @FindBy(id = "nav-menu")
    private WebElement menu;
    @FindBy(id = "Body")
    private WebElement body;

    public AfTabPage(WebDriver driver) {
        super(driver);
        waitForLoaded();
    }

    public void waitForLoaded() {
        DriverUtils.waitFor(getDriver(), () -> {
            return !body.getAttribute("style").equals("cursor: wait;");
        });
    }

    public WebElement getTab(String tabName){
        return getDriver().findElement(By.xpath(String.format("//a[contains(text(),'%s')]", tabName)));
    }

    public String getTabStatus(String tabName){
        return getTab(tabName).findElement(By.xpath("./parent::li")).getAttribute("class");
    }

    public boolean isTabActive(String tabName) {
        return getTabStatus(tabName).contains("topMenuActive");
    }

    public boolean isTabVisited(String tabName) {
        return getTabStatus(tabName).contains("topMenuVisited");
    }

    public boolean isNotTabVisited(String tabName) {
        return getTabStatus(tabName).contains("topMenuNotVisited");
    }

    public boolean isTabDisabled(String tabName) {
        return getTabStatus(tabName).contains("topMenuDisabled");
    }

    public boolean hasNoErrorMessage() {
        return getDriver().findElements(By.xpath("//a/string[text()='Show message(s)']")).isEmpty();
    }
}
