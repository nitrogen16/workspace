package com.ipipeline.automation.affirm.control;

import com.ipipeline.ngsd.ui.igo.elements.IgoCheckboxControl;
import org.openqa.selenium.WebElement;
import ru.yandex.qatools.htmlelements.element.CheckBox;

/**
 * Created by Aliaksandr_Vasilets on 7/14/2017.
 */
public class AfCheckboxControl extends IgoCheckboxControl {

    public AfCheckboxControl(WebElement wrappedElement) {
        super(wrappedElement);
    }

    @Override
    public CheckBox getElement() {
        return new CheckBox(getWrappedElement());
    }

}