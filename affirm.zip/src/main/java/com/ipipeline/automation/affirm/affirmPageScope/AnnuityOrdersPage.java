package com.ipipeline.automation.affirm.affirmPageScope;

import com.ipipeline.ngsd.ui.igo.pages.Page;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Created by Aliaksandr_Vasilets on 7/14/2017.
 */
public class AnnuityOrdersPage extends Page {

    @FindBy(xpath = "//input[@value='Enter New Business']")
    private WebElement enterNewBusinessButton;

    public AnnuityOrdersPage(WebDriver driver) {
        super(driver);
    }

    public AffirmPage enterNewBusiness() {
        enterNewBusinessButton.click();

        return switchToPage(AffirmPage.class);
    }

}
