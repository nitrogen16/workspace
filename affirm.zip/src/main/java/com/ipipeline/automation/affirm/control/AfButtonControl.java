package com.ipipeline.automation.affirm.control;

import com.ipipeline.ngsd.ui.igo.elements.IgoButtonControl;
import org.openqa.selenium.WebElement;
import ru.yandex.qatools.htmlelements.element.Button;

/**
 * Created by Aliaksandr_Vasilets on 7/14/2017.
 */
public class AfButtonControl extends IgoButtonControl {

    public AfButtonControl(WebElement wrappedElement) {
        super(wrappedElement);
    }

    public Button getElement() {
        return new Button(getWrappedElement());
    }

}