package com.ipipeline.automation.affirm.test;

import com.ipipeline.ngsd.ui.igo.elements.IgoRadioControl;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

/**
 * Keywords to interact with radio button control.
 *
 */
public class RadioButton extends com.ipipeline.ngsd.kedr.tests.RadioButton {

	@Override
	protected IgoRadioControl control() {
		return appPage().findRadioButton(getObjectName());
	}

	/**
	 * Select specified index in radio button group.
	 *
	 * @param select index to select.
	 */
	@Test
	@Parameters({ "select" })
	public void selectByIndex(int select) {
		control().getElement().selectByIndex(select);
	}
}
