package com.ipipeline.automation.affirm.test;

import com.ipipeline.automation.affirm.affirmPageScope.AfDialogPage;
import com.ipipeline.ngsd.kedr.tests.base.IgoKedrTest;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * Created by Aliaksandr_Vasilets on 7/14/2017.
 */
public class Dialog extends IgoKedrTest {
    @BeforeMethod
    public void beforeMethod() {
    }

    private AfDialogPage getPopUp() {
        return page(AfDialogPage.class);
    }

    @Test
    public void isDialogOpened() {
        Assert.assertFalse(getPopUp().getConfirmationWindow().isEmpty(), "Dialog window is not opened");
    }

    @Test
    public void isNotDialogOpened() {
        Assert.assertTrue(getPopUp().getConfirmationWindow().isEmpty(), "Dialog window is opened");
    }

    @Test
    public void confirmDialog() {
        getPopUp().confirmDialog();
    }

    @Test
    public void cancelDialog() {
        getPopUp().cancelDialog();
    }

    @Test
    public void closeDialog() {
        getPopUp().closeDialog();
    }

    @Test
    public void isOrderSubmitted() {
        Assert.assertTrue(getPopUp().isOrderSubmitted(), "Order is not submitted");
    }
}
