package com.ipipeline.automation.affirm.test;

import com.ipipeline.automation.affirm.affirmPageScope.AFLoginPage;
import com.ipipeline.ngsd.kedr.tests.base.IgoKedrTest;
import org.apache.commons.lang3.StringUtils;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

/**
 * Created by Aliaksandr_Vasilets on 7/14/2017.
 */
public class Affirm extends IgoKedrTest {
    @BeforeMethod
    public void beforeMethod() {
    }

    /**
     * Login in Affirm and open 'Enter New Business'.
     *
     * @param url
     * @param user
     * @param password
     */
    @Test
    @Parameters({"url", "user", "password"})
    public void startNewBusiness(String url, String user, String password) {
        String urlF = StringUtils.defaultIfBlank(getConfig().getIgoUrl(), url);
        String userF = StringUtils.defaultIfBlank(getConfig().getIgoUser(), user);
        String passwordF = StringUtils.defaultIfBlank(getConfig().getIgoPassword(), password);

        page(AFLoginPage.class).login(urlF, userF, passwordF).orderEntryDashboard().enterNewBusiness();
    }
}
