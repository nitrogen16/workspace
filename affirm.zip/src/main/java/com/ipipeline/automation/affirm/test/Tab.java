package com.ipipeline.automation.affirm.test;

import com.ipipeline.automation.affirm.affirmPageScope.AfTabPage;
import com.ipipeline.ngsd.kedr.tests.base.IgoKedrTest;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * Created by Aliaksandr_Vasilets on 7/19/2017.
 */
public class Tab extends IgoKedrTest {

    private AfTabPage getTab() {
        return page(AfTabPage.class);
    }

    @Test
    public void isTabActive() {
        Assert.assertTrue(getTab().isTabActive(getObjectName()), "Tab is not active");
    }

    @Test
    public void isTabVisited() {
        Assert.assertTrue(getTab().isTabVisited(getObjectName()), "Tab is not visited");
    }

    @Test
    public void isNotTabVisited() {
        Assert.assertTrue(getTab().isNotTabVisited(getObjectName()), "Tab is visited");
    }

    @Test
    public void isTabDisabled() {
        Assert.assertTrue(getTab().isTabDisabled(getObjectName()), "Tab is enabled");
    }

    @Test
    public void hasNoErrorMessage() {
        Assert.assertTrue(page(AfTabPage.class).hasNoErrorMessage(), "There are error messages");
    }
}
