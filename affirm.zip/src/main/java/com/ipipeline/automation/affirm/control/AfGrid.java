package com.ipipeline.automation.affirm.control;

import com.ipipeline.ngsd.ui.igo.elements.IgoGrid;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import ru.yandex.qatools.htmlelements.element.Select;

/**
 * Created by Aliaksandr_Vasilets on 7/14/2017.
 */
public class AfGrid extends IgoGrid {

    public AfGrid(WebElement wrappedElement) {
        super(wrappedElement);
    }

    public void typeValue(String rowNum, String colNum, String textValue) {
        getWrappedElement().findElement(By.xpath(String.format("./tr[%s]/td[%s]/input", rowNum, colNum))).sendKeys(textValue);
    }

    public void selectValue(String rowNum, String colNum, String selectValue) {
        new Select(getWrappedElement().findElement(By.xpath(String.format("./tr[%s]/td[%s]/select", rowNum, colNum)))).selectByVisibleText(selectValue);
    }

    public void clickCell(String rowNum, String colNum) {
        getWrappedElement().findElement(By.xpath(String.format("./tr[%s]/td[%s]/a", rowNum, colNum))).click();
    }

    @Override
    public void selectRow(int rowNumber) {
        getWrappedElement().findElement(By.xpath("./tr[" + rowNumber + "]//input")).click();
    }
}