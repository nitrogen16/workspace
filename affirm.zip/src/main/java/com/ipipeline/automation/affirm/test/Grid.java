package com.ipipeline.automation.affirm.test;

import com.ipipeline.automation.affirm.control.AfGrid;
import com.ipipeline.ngsd.ui.igo.elements.IgoGrid;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

/**
 * Keywords to interact with grid element.
 *
 */
public class Grid extends com.ipipeline.ngsd.kedr.tests.Grid {

	@Override
	protected IgoGrid control() {
		return appPage().findGrid(getObjectName());
	}

	/**
	 * Fill in specified  column for specified row
	 *
	 * @param rowNum
	 * @param colNum
	 * @param textValue
	 */
	@Test
	@Parameters({ "rowNum", "colNum", "textValue" })
	public void typeValue(String rowNum, String colNum, String textValue) {
		((AfGrid)control()).typeValue(rowNum, colNum, textValue);
	}

	@Test
	@Parameters({ "rowNum", "colNum", "textValue" })
	public void selectValue(String rowNum, String colNum, String textValue) {
		((AfGrid)control()).selectValue(rowNum, colNum, textValue);
	}
}
