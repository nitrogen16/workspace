package com.ipipeline.automation.affirm;

import com.ipipeline.automation.affirm.affirmPageScope.AffirmPage;
import com.ipipeline.ngsd.kedr.tests.base.AppPageManager;
import com.ipipeline.ngsd.ui.igo.pages.AppPage;

/**
 * Created by Aliaksandr_Vasilets on 7/14/2017.
 */
public class AffirmAppPageManager implements AppPageManager {
    @Override
    public Class<? extends AppPage<?>> get() {
        return AffirmPage.class;
    }

    @Override
    public void inIgo() {
        // TODO Auto-generated method stub
    }

    @Override
    public void onPreview() {
        // TODO Auto-generated method stub
    }

    @Override
    public void onClickWrap() {
        // TODO Auto-generated method stub
    }
}
