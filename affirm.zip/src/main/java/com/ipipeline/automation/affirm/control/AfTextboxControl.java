package com.ipipeline.automation.affirm.control;

import com.ipipeline.ngsd.ui.igo.elements.IgoTextboxControl;
import org.openqa.selenium.WebElement;
import ru.yandex.qatools.htmlelements.element.TextInput;

/**
 * Created by Aliaksandr_Vasilets on 7/14/2017.
 */
public class AfTextboxControl extends IgoTextboxControl {

    public AfTextboxControl(WebElement wrappedElement) {
        super(wrappedElement);
    }

    @Override
    public TextInput getElement() {
        return new TextInput(getWrappedElement());
    }

}
