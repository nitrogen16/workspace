package com.ipipeline.automation.affirm.affirmPageScope;

import com.ipipeline.automation.affirm.control.*;
import com.ipipeline.ngsd.ui.igo.elements.*;
import com.ipipeline.ngsd.ui.igo.pages.AppPage;
import com.ipipeline.ngsd.ui.igo.pages.exceptions.PageRuntimeException;
import org.openqa.selenium.*;

/**
 * Created by Aliaksandr_Vasilets on 7/14/2017.
 */
public class AffirmPage extends AppPage<AffirmPage> {

    public AffirmPage(WebDriver driver) {
        super(driver, null);
        // TODO Auto-generated constructor stub
    }

    @Override
    public AffirmPage openScreen(String screenName) {
        // TODO Auto-generated method stub
        return null;
    }

    private WebElement getWrapped(String controlName) {
        try {
            WebElement control = getDriver().findElement(By.xpath(String.format("//*[contains(text(), '%s')]", controlName)));
            ((JavascriptExecutor)getDriver()).executeScript("arguments[0].scrollIntoView();", control);
            return control;
        } catch (NoSuchElementException e) {
            throw new PageRuntimeException(String.format("Control not found: %s", controlName));
        }
    }

    @Override
    public IgoTextboxControl findTextbox(String textboxName) {
        return new AfTextboxControl(getWrapped(textboxName).findElement(By.xpath("./following::input[1]")));
    }

    @Override
    public IgoButtonControl findButton(String buttonName) {
        return new AfButtonControl(getDriver().findElement(By.xpath(String.format("//input[@value='%s']", buttonName))));
    }

    @Override
    public IgoDropdownControl findDropdown(String selectName) {
        return new AfDropdownControl(getWrapped(selectName).findElement(By.xpath("./following::select[1]")));
    }

    @Override
    public IgoCheckboxControl findCheckbox(String checkboxName) {
        return new AfCheckboxControl(getWrapped(checkboxName).findElement(By.xpath(String.format("./preceding::input[@type='checkbox']", checkboxName))));
    }

    @Override
    public IgoGrid findGrid(String gridName) {
        WebElement grid;
        try{
            grid = getWrapped(gridName).findElement(By.xpath("./ancestor::table[@id='contentTable']//tbody//tbody"));
        } catch (NoSuchElementException ex){
            grid = getWrapped(gridName).findElement(By.xpath("./ancestor::tbody[1]"));
        }
        return new AfGrid(grid);
    }

    @Override
    public IgoRadioControl findRadioButton(String radioName) {
        WebElement radio;
        try{
            radio = getWrapped(radioName).findElement(By.xpath("./ancestor-or-self::td[1]/following-sibling::td//input[@type='radio']"));
        } catch (NoSuchElementException ex){
            radio = getWrapped(radioName);
        }
        return new AfRadioControl(radio);
    }

}
