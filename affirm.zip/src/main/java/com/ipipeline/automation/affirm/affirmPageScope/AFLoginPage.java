package com.ipipeline.automation.affirm.affirmPageScope;

import com.ipipeline.ngsd.ui.igo.pages.Page;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * Created by Aliaksandr_Vasilets on 7/14/2017.
 */
public class AFLoginPage extends Page {

    private WebElement UserName;
    private WebElement Password;
    private WebElement BtnLogin;

    public AFLoginPage(WebDriver driver) {
        super(driver);
    }

    public HomePage login(String url, String user, String password) {
        getDriver().get(url);
        getDriver().manage().window().maximize();

        UserName.sendKeys(user);
        Password.sendKeys(password);
        BtnLogin.click();

        return switchToPage(HomePage.class);
    }
}
