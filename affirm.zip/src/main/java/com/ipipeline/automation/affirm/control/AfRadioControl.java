package com.ipipeline.automation.affirm.control;

import com.ipipeline.ngsd.ui.igo.elements.IgoRadioControl;
import org.openqa.selenium.WebElement;
import ru.yandex.qatools.htmlelements.element.Radio;

/**
 * Created by Aliaksandr_Vasilets on 7/14/2017.
 */
public class AfRadioControl extends IgoRadioControl {

    public AfRadioControl(WebElement wrappedElement) {
        super(wrappedElement);
    }

    @Override
    public Radio getElement() {
        return new Radio(getWrappedElement());
    }
}
