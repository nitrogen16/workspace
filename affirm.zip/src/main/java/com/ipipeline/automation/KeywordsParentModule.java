package com.ipipeline.automation;

import com.google.inject.AbstractModule;
import com.google.inject.Scopes;
import com.ipipeline.automation.affirm.AffirmAppPageManager;
import com.ipipeline.automation.config.TestConfig;
import com.ipipeline.automation.driver.WebDriverProvider;
import com.ipipeline.ngsd.kedr.tests.base.AppPageManager;
import com.ipipeline.ngsd.kedr.tests.base.WDProvider;
import com.ipipeline.ngsd.kedr.tests.config.IgoConfig;
import com.ipipeline.ngsd.kedr.tests.config.SDToolConfig;
import com.ipipeline.ngsd.kedr.tests.data.IgoCaseData;

public class KeywordsParentModule extends AbstractModule {

	@Override
	protected void configure() {
		TestConfig config = Runner.getConfig();
		IgoConfig igoConfig = new IgoConfig();
		
		igoConfig.setIgoUrl(config.getIgoUrl());
		igoConfig.setIgoUser(config.getIgoUser());
		igoConfig.setIgoPassword(config.getIgoPassword());
		igoConfig.setIgoState(config.getIgoState());
		igoConfig.setIgoProductType(config.getIgoProductType());
		igoConfig.setIgoProduct(config.getIgoProduct());
//		igoConfig.setDownloadDir(config.getDownloadDir().getAbsolutePath());
//		igoConfig.setKeepBrowser(config.isKeepBrowser());
//		igoConfig.setPdfBaseDir(config.getPdfBaseDir());
//		igoConfig.setBcDir(config.getBcDir());
		
		igoConfig.setJira(config.isJira());
		igoConfig.setJiraUsername(config.getJiraUsername());
		igoConfig.setJiraPassword(config.getJiraPassword());
		
		SDToolConfig sdConfig = new SDToolConfig();
		
		bind(IgoConfig.class).toInstance(igoConfig);
		bind(SDToolConfig.class).toInstance(sdConfig);

		config.setIgoConfig(igoConfig);
		bind(TestConfig.class).toInstance(config);
		
		bind(WDProvider.class).to(WebDriverProvider.class).in(Scopes.SINGLETON);
//		bind(AppPageManager.class).to(NGSDAppPageManager.class).in(Scopes.SINGLETON);
		bind(IgoCaseData.class).in(Scopes.SINGLETON);
		bind(AppPageManager.class).to(AffirmAppPageManager.class).in(Scopes.SINGLETON);
	}

}