package com.ipipeline.automation;

import com.epam.reportportal.listeners.ListenerParameters;
import com.epam.reportportal.service.ReportPortalClient;
import com.epam.reportportal.testng.TestNGService;
import com.epam.ta.reportportal.ws.model.StartTestItemRQ;
import io.reactivex.Maybe;
import org.testng.ITestResult;

public class CustomTestNgService extends TestNGService {
    private static String launchId;
    private static String suiteId;
    private static String testId;
    private static String testMethodId;
    private static final String ENDPOINT = "https://rp.epam.com";
    private static final String PRJ_NAME = "IPLN-TST";
    private StartTestItemRQ rq;

    public CustomTestNgService(ListenerParameters parameters, ReportPortalClient reportPortalClient) {
        super(parameters, reportPortalClient);
    }
/*
   @Override
    public void startTestSuite(ISuite suite) {
        super.startTestSuite(suite);
        CustomTestNgService.launchId = this.rq.getLaunchId();
    }

    @Override
    public StartTestItemRQ buildStartSuiteRq(ISuite suite) {
        StartTestItemRQ rq = super.buildStartSuiteRq(suite);
        this.rq = rq;
        return rq;
    }

    @Override
    public void finishTestMethod(String status, ITestResult testResult) {
        super.finishTestMethod(status, testResult);
        if(status.equals("FAILED")){setId(testResult);}
    }
*/
    private void setId(ITestResult result){
        Maybe<String> idSuite = getAttribute(result.getTestContext().getSuite(), TestNGService.RP_ID);
        idSuite.doOnSuccess(id -> CustomTestNgService.suiteId = id).subscribe();
        Maybe<String> idTest = getAttribute(result.getTestContext(), TestNGService.RP_ID);
        idTest.doOnSuccess(id -> CustomTestNgService.testId = id).subscribe();
        Maybe<String> idMethod = getAttribute(result, TestNGService.RP_ID);
        idMethod.doOnSuccess(id -> CustomTestNgService.testMethodId = id).subscribe();
    }

    public static String getUrl(){
        String url = ENDPOINT.concat("/#").concat(PRJ_NAME.toLowerCase()).concat("/launches/all/")
                .concat(launchId).concat("/")
                .concat(suiteId).concat("/")
                .concat(testId).concat("?log.item=").concat(testMethodId);
        return url;
    }
}
