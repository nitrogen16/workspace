package com.ipipeline.automation;

import java.io.File;
import java.io.IOException;

import com.epam.reportportal.listeners.ListenerParameters;
import com.epam.reportportal.service.ReportPortalClient;
import com.epam.reportportal.testng.BaseTestNGListener;
import com.epam.reportportal.testng.ITestNGService;
import com.epam.reportportal.testng.TestNGAgentModule;
import com.epam.reportportal.testng.TestNGProvider;
import com.epam.reportportal.testng.TestNGService;
import com.ipipeline.ngsd.kedr.tests.JiraCase;
import com.ipipeline.ngsd.kedr.tests.Pdf;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.time.FastDateFormat;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;

import com.epam.reportportal.message.ReportPortalMessage;
import com.ipipeline.ngsd.other.WebDriverAware;
import com.ipipeline.ngsd.other.KedrTest;
import rp.com.google.inject.Module;

import static rp.com.google.inject.util.Modules.override;

public class TestResultsListener extends BaseTestNGListener {

	private static String DEFAULT_TIMESTAMP_PATTERN = "yyyy-MM-dd_HH-mm-ss";

	protected static final Logger LOGGER = Logger.getLogger(TestResultsListener.class);

	public TestResultsListener() {
		super(override(new TestNGAgentModule()).with(
				(Module) binder -> binder.bind(ITestNGService.class).toProvider(new TestNGProvider() {
					@Override
					protected TestNGService createTestNgService(
							ListenerParameters listenerParameters,
							ReportPortalClient reportPortalClient) {
						return new CustomTestNgService(listenerParameters, reportPortalClient);
					}
				})));
	}

	@Override
	public void onTestFailure(ITestResult result) {
		result.getThrowable().printStackTrace();
		logFail(result);
		super.onTestFailure(result);
		JiraCase.jiraCaseStatus = JiraCase.Status.FAILED;
	}

	@Override
	public void onConfigurationFailure(ITestResult itr) {
		logFail(itr);
		super.onConfigurationFailure(itr);
		JiraCase.jiraCaseStatus = JiraCase.Status.FAILED;
	}

	@Override
	public void onTestStart(ITestResult result) {
		String testName = ((KedrTest) result.getInstance()).getTestName();
		String keyword = result.getMethod().getMethodName();
		LOGGER.info(testName + " : " + keyword);
		super.onTestStart(result);
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		String testName = ((KedrTest) result.getInstance()).getTestName();
		String keyword = result.getMethod().getMethodName();
		LOGGER.info(testName + " : " + keyword + " : Skipped");
		super.onTestSkipped(result);
	}

	private void logFail(ITestResult result) {
		if (result.getInstance() instanceof WebDriverAware && !result.getInstanceName().contains("Acord")) {
			WebDriver driver = ((WebDriverAware) result.getInstance()).getDriver();
			File srcScreenshot, destScreenshot;
			
			LOGGER.info("Current URL : " + driver.getCurrentUrl());
			
			try {
				srcScreenshot = takeScreenShot(driver);
				ReportPortalMessage message = new ReportPortalMessage(srcScreenshot, "Screenshot on error");
				LOGGER.debug(message);
				LOGGER.info(message);
			} catch (Throwable e) {
				LOGGER.info("Failed to take screenshot : " + e.getMessage());
				
				return;
			}
			
			try {
				String timeStamp = FastDateFormat.getInstance(DEFAULT_TIMESTAMP_PATTERN).format(System.currentTimeMillis());
				
				String destFileName = timeStamp + "_" + testName(result) + ".png";
				destScreenshot = new File(FilenameUtils.getFullPath(srcScreenshot.getAbsolutePath()), destFileName);
				FileUtils.moveFile(srcScreenshot, destScreenshot);
				
				LOGGER.info("Screenshot : " + destScreenshot);
			} catch (Exception e) {
				LOGGER.info("Screenshot : " + srcScreenshot);
			}
		} else {
			LOGGER.info("Screenshots are unavailable for test class " + result.getInstanceName());
		}
		
		if (null != result.getThrowable()) {
			LOGGER.info("Test execution error", result.getThrowable());
		}
	}

	private String testName(ITestResult result) {
		return result.getInstance().getClass().getSimpleName() + "." + result.getMethod().getMethodName();
	}

	public static File takeScreenShot(WebDriver driver) {
		File screenShot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		
		try {
			File destScreenshotFile = new File("test-output/screenshots/" + System.currentTimeMillis() + ".png");
			FileUtils.moveFile(screenShot, destScreenshotFile);
			
			return destScreenshotFile;
		} catch (IOException e) {
			return null;
		} finally {
			FileUtils.deleteQuietly(screenShot);
		}
	}

}