package com.ipipeline.automation;

import java.io.File;
import java.util.List;

import com.ipipeline.automation.affirm.test.Affirm;
import com.ipipeline.ngsd.kedr.tests.IGo;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.testng.ITestNGListener;
import org.testng.TestNG;
import org.testng.xml.XmlSuite;

import com.epam.automation.KWDTestNGBuilder;
import com.ipipeline.automation.config.TestConfig;

public class Runner {

	private static TestConfig config;

	public static void main(String[] args) {
		config = new TestConfig();
		
		try {
			new CmdLineParser(config).parseArgument(args);
		} catch (CmdLineException e) {
			throw new RuntimeException(e);
		}
		
		KWDTestNGBuilder kwdBuilder = new KWDTestNGBuilder();
		
		kwdBuilder.addKeywordsPackages(IGo.class.getPackage().getName());
		kwdBuilder.addKeywordsPackages(Affirm.class.getPackage().getName());
		kwdBuilder.addCasePath(new File(config.getSource()));
		
		List<XmlSuite> xmlSuiteList = kwdBuilder.buildSuiteList();
		
		xmlSuiteList.forEach(xmlSuite -> xmlSuite.setParentModule(KeywordsParentModule.class.getName()));
		
		TestNG testNG = kwdBuilder.buildAsTestNG();
		
		testNG.addListener((ITestNGListener) new TestResultsListener());
		
		config.setSuitesProperties(kwdBuilder.getSuitesProperties());
		try{
			testNG.run();
		} finally {
			System.exit(0);
		}

	}

	public static TestConfig getConfig() {
		return config;
	}

}